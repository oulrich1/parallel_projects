#! /usr/bin/bash
ssh juch-s04@207.108.8.131
