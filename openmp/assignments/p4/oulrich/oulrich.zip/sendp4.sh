scp gaussian.c Makefile  juch-s04@207.108.8.131:~/p4
